const list = [
  {
    id: 1,
    title: " Face Moisturizer",
    price: 89,
    img: "https://cdn.shopify.com/s/files/1/0639/4812/8508/products/huron_face-moisturizer3.4gray.jpg?v=1650475410",
    amount: 1,
  },
  {
    id: 2,
    title: "Eye Stick 2.0",

    price: 98,
    img: "https://cdn.shopify.com/s/files/1/0639/4812/8508/products/huron_eyestick2_checkout.jpg?v=1651523648",
    amount: 1,
  },
  {
    id: 3,
    title: "Face Wash",

    price: 143,
    img: "https://cdn.shopify.com/s/files/1/0639/4812/8508/products/Hurontravelfacewash.jpg?v=1650475258&width=493",
    amount: 1,
  },
  {
    id: 4,
    title: "Travel wash",

    price: 57,
    img: "https://cdn.shopify.com/s/files/1/0639/4812/8508/products/Huron_shower-kit_83ce0144-81e4-4c0b-9bfe-85f6b121b8e1.jpg?v=1650475884",
    amount: 1,
  },
];

export default list;
