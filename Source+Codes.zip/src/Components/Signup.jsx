import React from "react";

const Signup = () => {
  return <div></div>;
};

export default Signup;
